// Background v7.0 - On-Demand reCAPTCHA Generator

console.log('[Genyu BG] Background v7.0 - On-Demand Token Generator');

// Poll server for pending token requests
async function checkPendingRequests() {
    try {
        const response = await fetch('http://localhost:3001/api/genyu/check-pending-requests');
        const data = await response.json();

        if (data.hasPending && data.requests.length > 0) {
            console.log('[Genyu BG] 🔔 Pending token request detected:', data.requests);

            // Process each request
            for (const requestId of data.requests) {
                await generateAndSubmitToken(requestId);
            }
        }
    } catch (e) {
        // Server might be down, ignore
    }
}

// Generate fresh reCAPTCHA and submit to server
async function generateAndSubmitToken(requestId) {
    console.log('[Genyu BG] 🔑 Generating fresh reCAPTCHA for request:', requestId);

    try {
        // Find labs.google.com tab
        const tabs = await chrome.tabs.query({});
        const labsTab = tabs.find(tab =>
            tab.url && (tab.url.includes('labs.google.com') || tab.url.includes('labs.google/'))
        );

        if (!labsTab) {
            console.error('[Genyu BG] ❌ No labs.google.com tab found!');
            return;
        }

        // Execute reCAPTCHA generation in the page
        const results = await chrome.scripting.executeScript({
            target: { tabId: labsTab.id },
            func: async () => {
                if (typeof grecaptcha === 'undefined') {
                    return { error: 'grecaptcha not loaded' };
                }

                try {
                    const token = await grecaptcha.enterprise.execute(
                        "6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV",
                        { action: "FLOW_GENERATION" }
                    );

                    console.log('[Genyu Page] 🔑 Fresh token generated:', token.substring(0, 50) + '...');
                    return { token };
                } catch (e) {
                    return { error: e.message };
                }
            },
            world: 'MAIN'
        });

        const result = results[0]?.result;

        if (result?.error) {
            console.error('[Genyu BG] ❌ Token generation error:', result.error);
            return;
        }

        if (!result?.token) {
            console.error('[Genyu BG] ❌ No token returned');
            return;
        }

        const token = result.token;
        console.log('[Genyu BG] ✅ Token generated:', token.substring(0, 50) + '... (', token.length, 'chars)');

        // Submit to server
        const submitResponse = await fetch('http://localhost:3001/api/genyu/submit-fresh-token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                requestId,
                token
            })
        });

        const submitData = await submitResponse.json();
        console.log('[Genyu BG] ✅ Token submitted:', submitData);

    } catch (e) {
        console.error('[Genyu BG] ❌ Error:', e.message);
    }
}

// Poll every 2 seconds for pending requests
setInterval(checkPendingRequests, 2000);

console.log('[Genyu BG] ✅ Ready - Polling for token requests every 2s');
